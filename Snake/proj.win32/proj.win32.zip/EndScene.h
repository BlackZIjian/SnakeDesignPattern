#ifndef __END_SCENE_H__
#define __END_SCENE_H__

#include "cocos2d.h"


class EndScene : public cocos2d::Scene
{
public:
	EndScene();
	~EndScene();

};




#endif
