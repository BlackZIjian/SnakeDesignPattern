#ifndef __DOUBLE_SCENE_H__
#define __DOUBLE_SCENE_H__

#include "cocos2d.h"

class DoubleScene : public cocos2d::Scene
{
public:
	DoubleScene();
	~DoubleScene();

};




#endif
